// Game data with currency and denominations
const gameData = {
  'mobile-legends': {
    name: 'Mobile Legends',
    currency: 'Diamond',
    denominations: [
      { value: '5', label: '5 Diamond - Rp 2.000' },
      { value: '11', label: '11 Diamond - Rp 4.000' },
      { value: '28', label: '28 Diamond - Rp 10.000' },
      { value: '59', label: '59 Diamond - Rp 20.000' },
      { value: '86', label: '86 Diamond - Rp 30.000' },
      { value: '172', label: '172 Diamond - Rp 60.000' },
      { value: '257', label: '257 Diamond - Rp 90.000' },
      { value: '344', label: '344 Diamond - Rp 120.000' },
      { value: '429', label: '429 Diamond - Rp 150.000' },
      { value: '514', label: '514 Diamond - Rp 180.000' },
      { value: '600', label: '600 Diamond - Rp 210.000' },
      { value: '706', label: '706 Diamond - Rp 250.000' },
      { value: '878', label: '878 Diamond - Rp 300.000' },
      { value: '1050', label: '1050 Diamond - Rp 350.000' },
      { value: '1222', label: '1222 Diamond - Rp 400.000' },
      { value: '1930', label: '1930 Diamond - Rp 600.000' },
      { value: '2444', label: '2444 Diamond - Rp 750.000' },
      { value: '2956', label: '2956 Diamond - Rp 900.000' },
      { value: '3688', label: '3688 Diamond - Rp 1.100.000' },
      { value: '4032', label: '4032 Diamond - Rp 1.200.000' },
      { value: '4830', label: '4830 Diamond - Rp 1.400.000' },
      { value: '5540', label: '5540 Diamond - Rp 1.600.000' },
      { value: '6250', label: '6250 Diamond - Rp 1.800.000' },
      { value: '7480', label: '7480 Diamond - Rp 2.100.000' }
    ]
  },
  'pubg': {
    name: 'PUBG Mobile',
    currency: 'UC',
    denominations: [
      { value: '60', label: '60 UC - Rp 2.000' },
      { value: '300', label: '300 UC - Rp 10.000' },
      { value: '600', label: '600 UC - Rp 20.000' },
      { value: '1500', label: '1500 UC - Rp 50.000' },
      { value: '3000', label: '3000 UC - Rp 100.000' },
      { value: '6000', label: '6000 UC - Rp 200.000' },
      { value: '9000', label: '9000 UC - Rp 300.000' },
      { value: '15000', label: '15000 UC - Rp 500.000' }
    ]
  },
  'free-fire': {
    name: 'Free Fire',
    currency: 'Diamond',
    denominations: [
      { value: '5', label: '5 Diamond - Rp 2.000' },
      { value: '12', label: '12 Diamond - Rp 4.000' },
      { value: '50', label: '50 Diamond - Rp 15.000' },
      { value: '70', label: '70 Diamond - Rp 20.000' },
      { value: '140', label: '140 Diamond - Rp 40.000' },
      { value: '210', label: '210 Diamond - Rp 60.000' },
      { value: '355', label: '355 Diamond - Rp 100.000' },
      { value: '500', label: '500 Diamond - Rp 140.000' },
      { value: '720', label: '720 Diamond - Rp 200.000' },
      { value: '1000', label: '1000 Diamond - Rp 280.000' },
      { value: '1440', label: '1440 Diamond - Rp 400.000' },
      { value: '2000', label: '2000 Diamond - Rp 550.000' },
      { value: '2880', label: '2880 Diamond - Rp 800.000' },
      { value: '4000', label: '4000 Diamond - Rp 1.100.000' },
      { value: '5750', label: '5750 Diamond - Rp 1.550.000' },
      { value: '7300', label: '7300 Diamond - Rp 2.000.000' }
    ]
  },
  'codm': {
    name: 'COD Mobile',
    currency: 'CP',
    denominations: [
      { value: '50', label: '50 CP - Rp 2.000' },
      { value: '120', label: '120 CP - Rp 5.000' },
      { value: '240', label: '240 CP - Rp 10.000' },
      { value: '480', label: '480 CP - Rp 20.000' },
      { value: '800', label: '800 CP - Rp 30.000' },
      { value: '1200', label: '1200 CP - Rp 50.000' },
      { value: '2400', label: '2400 CP - Rp 100.000' },
      { value: '4000', label: '4000 CP - Rp 150.000' },
      { value: '6000', label: '6000 CP - Rp 200.000' },
      { value: '8000', label: '8000 CP - Rp 300.000' }
    ]
  },
  'genshin': {
    name: 'Genshin Impact',
    currency: 'Genesis Crystal',
    denominations: [
      { value: '60', label: '60 Genesis Crystal - Rp 2.000' },
      { value: '300', label: '300 Genesis Crystal - Rp 10.000' },
      { value: '980', label: '980 Genesis Crystal - Rp 30.000' },
      { value: '1980', label: '1980 Genesis Crystal - Rp 60.000' },
      { value: '3280', label: '3280 Genesis Crystal - Rp 100.000' },
      { value: '6480', label: '6480 Genesis Crystal - Rp 200.000' }
    ]
  },
  'valorant': {
    name: 'Valorant',
    currency: 'VP',
    denominations: [
      { value: '425', label: '425 VP - Rp 2.000' },
      { value: '1000', label: '1000 VP - Rp 50.000' },
      { value: '2050', label: '2050 VP - Rp 100.000' },
      { value: '4200', label: '4200 VP - Rp 200.000' },
      { value: '7000', label: '7000 VP - Rp 350.000' },
      { value: '13750', label: '13750 VP - Rp 700.000' }
    ]
  },
  'aov': {
    name: 'Arena of Valor',
    currency: 'Voucher',
    denominations: [
      { value: '1', label: '1 Voucher - Rp 2.000' },
      { value: '5', label: '5 Voucher - Rp 10.000' },
      { value: '12', label: '12 Voucher - Rp 25.000' },
      { value: '25', label: '25 Voucher - Rp 50.000' },
      { value: '50', label: '50 Voucher - Rp 100.000' },
      { value: '100', label: '100 Voucher - Rp 200.000' },
      { value: '250', label: '250 Voucher - Rp 500.000' },
      { value: '500', label: '500 Voucher - Rp 1.000.000' }
    ]
  },
  'higgs': {
    name: 'Higgs Domino',
    currency: 'Chip',
    denominations: [
      { value: '10M', label: '10M Chip - Rp 2.000' },
      { value: '50M', label: '50M Chip - Rp 10.000' },
      { value: '100M', label: '100M Chip - Rp 20.000' },
      { value: '200M', label: '200M Chip - Rp 40.000' },
      { value: '500M', label: '500M Chip - Rp 100.000' },
      { value: '1B', label: '1B Chip - Rp 200.000' },
      { value: '2B', label: '2B Chip - Rp 400.000' },
      { value: '5B', label: '5B Chip - Rp 1.000.000' }
    ]
  },
  'roblox': {
    name: 'Roblox',
    currency: 'Robux',
    denominations: [
      { value: '80', label: '80 Robux - Rp 2.000' },
      { value: '400', label: '400 Robux - Rp 10.000' },
      { value: '800', label: '800 Robux - Rp 20.000' },
      { value: '1700', label: '1700 Robux - Rp 40.000' },
      { value: '2000', label: '2000 Robux - Rp 50.000' },
      { value: '4500', label: '4500 Robux - Rp 100.000' },
      { value: '10000', label: '10.000 Robux - Rp 200.000' },
      { value: '22500', label: '22.500 Robux - Rp 450.000' }
    ]
  }
};

// Sound effects
const sounds = {
  click: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZURE'),
  success: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZURE'),
  notification: new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZURE')
};
let soundEnabled = true;

// Loading Screen
window.addEventListener('load', function() {
  setTimeout(() => {
    document.getElementById('loadingScreen').classList.add('hidden');
    // Initialize countdown timer
    startCountdown();
    // Initialize currency converter
    updateCurrencyConverter();
    // Initialize wishlist
    updateWishlistDisplay();
    // Initialize server status
    updateServerStatus();
    // Initialize payment history
    updateTransactionHistory();
    // Initialize quick top-up
    showQuickTopup();
    // Start simulating notifications
    setTimeout(simulateRealtimeNotifications, 5000);
    // Start server status simulation
    simulateServerStatusChanges();
  }, 2000);
});

// Particles Background
function createParticles() {
  const particlesBg = document.getElementById('particles-bg');
  const particleCount = 50;
  
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement('div');
    particle.classList.add('particle');
    
    const size = Math.random() * 5 + 2;
    const posX = Math.random() * window.innerWidth;
    const delay = Math.random() * 15;
    const duration = Math.random() * 10 + 15;
    const colors = ['var(--neon)', 'var(--neon-blue)', 'var(--neon-green)', 'var(--neon-pink)', 'var(--neon-purple)'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    particle.style.left = `${posX}px`;
    particle.style.animationDelay = `${delay}s`;
    particle.style.animationDuration = `${duration}s`;
    particle.style.background = color;
    
    particlesBg.appendChild(particle);
  }
}
createParticles();

// Dark Mode Toggle
const darkModeToggle = document.getElementById('darkModeToggle');
darkModeToggle.addEventListener('click', function() {
  document.body.classList.toggle('light-mode');
  const icon = this.querySelector('i');
  const text = this.querySelector('span');
  
  if (document.body.classList.contains('light-mode')) {
    icon.classList.remove('fa-moon');
    icon.classList.add('fa-sun');
    text.textContent = 'Light Mode';
  } else {
    icon.classList.remove('fa-sun');
    icon.classList.add('fa-moon');
    text.textContent = 'Dark Mode';
  }
  
  playSound('click');
});

// User Menu
const userBtn = document.querySelector('.user-btn');
const userDropdown = document.querySelector('.user-dropdown');
userBtn.addEventListener('click', function() {
  userDropdown.classList.toggle('show');
  playSound('click');
});
document.addEventListener('click', function(e) {
  if (!userBtn.contains(e.target) && !userDropdown.contains(e.target)) {
    userDropdown.classList.remove('show');
  }
});

// Counter Animation
function animateCounter() {
  const counters = document.querySelectorAll('.stat-number');
  
  counters.forEach(counter => {
    const target = +counter.getAttribute('data-count');
    const increment = target / 200;
    
    const updateCounter = () => {
      const current = +counter.innerText;
      
      if (current < target) {
        counter.innerText = Math.ceil(current + increment);
        setTimeout(updateCounter, 10);
      } else {
        counter.innerText = target;
      }
    };
    
    updateCounter();
  });
}

// Trigger counter animation when in viewport
const observerOptions = {
  threshold: 0.5
};
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      animateCounter();
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);
const statsSection = document.querySelector('.stats-section');
observer.observe(statsSection);

// Slider Functionality
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.slider-dot');
const prevBtn = document.querySelector('.nav-btn.prev');
const nextBtn = document.querySelector('.nav-btn.next');
let currentSlide = 0;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.remove('active', 'prev');
    if (i === index) {
      slide.classList.add('active');
    } else if (i < index) {
      slide.classList.add('prev');
    }
  });
  
  dots.forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });
  
  currentSlide = index;
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

nextBtn.addEventListener('click', () => {
  nextSlide();
  playSound('click');
});

prevBtn.addEventListener('click', () => {
  prevSlide();
  playSound('click');
});

dots.forEach((dot, index) => {
  dot.addEventListener('click', () => {
    showSlide(index);
    playSound('click');
  });
});

// Auto-slide
setInterval(nextSlide, 5000);

// Search Functionality
const searchInput = document.getElementById('searchInput');
const gameCards = document.querySelectorAll('.game-card');

searchInput.addEventListener('input', function() {
  const searchTerm = this.value.toLowerCase();
  
  gameCards.forEach(card => {
    const gameName = card.querySelector('.game-name').textContent.toLowerCase();
    const gameCurrency = card.querySelector('.game-currency').textContent.toLowerCase();
    
    if (gameName.includes(searchTerm) || gameCurrency.includes(searchTerm)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
});

// Modal Functionality
const modal = document.getElementById('topUpModal');
const modalGameName = document.getElementById('modalGameName');
const closeBtn = document.querySelector('.close-btn');
const cancelBtn = document.getElementById('cancelBtn');
const topUpForm = document.getElementById('topUpForm');
const denomSelect = document.getElementById('denom');

gameCards.forEach(card => {
  card.addEventListener('click', function() {
    const gameKey = this.getAttribute('data-game');
    const gameName = this.getAttribute('data-currency') ? 
                    `${this.querySelector('.game-name').textContent} (${this.getAttribute('data-currency')})` : 
                    this.querySelector('.game-name').textContent;
    
    modalGameName.textContent = gameName;
    
    // Clear previous options
    denomSelect.innerHTML = '<option value="">-- Pilih Nominal --</option>';
    
    // Add game-specific denominations
    if (gameData[gameKey] && gameData[gameKey].denominations) {
      gameData[gameKey].denominations.forEach(denom => {
        const option = document.createElement('option');
        option.value = denom.value;
        option.textContent = denom.label;
        denomSelect.appendChild(option);
      });
    }
    
    // Store game key for later use
    modal.setAttribute('data-game-key', gameKey);
    
    modal.classList.add('show');
    playSound('click');
  });
});

function closeModal() {
  modal.classList.remove('show');
  topUpForm.reset();
}

closeBtn.addEventListener('click', () => {
  closeModal();
  playSound('click');
});

cancelBtn.addEventListener('click', () => {
  closeModal();
  playSound('click');
});

modal.addEventListener('click', function(e) {
  if (e.target === modal) {
    closeModal();
  }
});

// Payment Success Animation
function showPaymentSuccess(gameName, playerId, denom, payment, total) {
  console.log('showPaymentSuccess called:', {gameName, playerId, denom, payment, total});
  
  // Pastikan elemen ada
  const successElement = document.getElementById('paymentSuccess');
  if (!successElement) {
    console.error('Payment success element not found');
    return;
  }
  
  // Isi data
  document.getElementById('successGame').textContent = gameName;
  document.getElementById('successPlayerId').textContent = playerId;
  document.getElementById('successDenom').textContent = denom;
  document.getElementById('successPayment').textContent = payment.toUpperCase();
  document.getElementById('successTotal').textContent = total;
  
  // Reset animasi
  successElement.classList.remove('show');
  successElement.style.display = 'none';
  successElement.style.opacity = '0';
  successElement.style.visibility = 'hidden';
  successElement.style.pointerEvents = 'none';
  
  // Force reflow
  void successElement.offsetWidth;
  
  // Tampilkan dengan animasi
  setTimeout(() => {
    successElement.style.display = 'flex';
    successElement.style.visibility = 'visible';
    successElement.style.pointerEvents = 'auto';
    successElement.classList.add('show');
    
    // Debug: cek apakah tombol terlihat dan bisa diklik
    setTimeout(() => {
      const btn = document.getElementById('successBtn');
      if (btn) {
        console.log('Button visible:', btn.offsetParent !== null);
        console.log('Button position:', btn.getBoundingClientRect());
        console.log('Button z-index:', window.getComputedStyle(btn).zIndex);
        console.log('Button pointer-events:', window.getComputedStyle(btn).pointerEvents);
        
        // Pastikan tombol bisa diklik
        btn.style.pointerEvents = 'auto';
        btn.style.cursor = 'pointer';
      }
    }, 100);
  }, 100);
  
  playSound('success');
  createConfetti();
}

function createConfetti() {
  const colors = ['var(--neon-green)', 'var(--neon-blue)', 'var(--neon-pink)', 'var(--neon-yellow)', 'var(--neon-purple)'];
  
  for (let i = 0; i < 100; i++) {
    setTimeout(() => {
      const confetti = document.createElement('div');
      confetti.classList.add('confetti');
      
      const size = Math.random() * 10 + 5;
      const posX = Math.random() * window.innerWidth;
      const color = colors[Math.floor(Math.random() * colors.length)];
      
      confetti.style.width = `${size}px`;
      confetti.style.height = `${size}px`;
      confetti.style.left = `${posX}px`;
      confetti.style.background = color;
      confetti.style.animationDuration = `${Math.random() * 3 + 2}s`;
      
      document.body.appendChild(confetti);
      
      setTimeout(() => {
        confetti.remove();
      }, 5000);
    }, i * 30);
  }
}

// Form submission
topUpForm.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const gameKey = modal.getAttribute('data-game-key');
  const gameName = modalGameName.textContent;
  const playerId = document.getElementById('playerId').value;
  const denomValue = document.getElementById('denom').value;
  const payment = document.getElementById('payment').value;
  
  // Validasi input
  if (!playerId || !denomValue || !payment) {
    showNotification('Peringatan', 'Harap isi semua field', 'warning');
    return;
  }
  
  // Get denomination details
  const selectedOption = document.querySelector(`#denom option[value="${denomValue}"]`);
  const denomLabel = selectedOption ? selectedOption.textContent : denomValue;
  const priceMatch = denomLabel.match(/Rp ([\d.]+)/);
  const price = priceMatch ? `Rp ${priceMatch[1]}` : 'Rp 0';
  
  // Close modal terlebih dahulu
  closeModal();
  
  // Tunggu modal tertutup sepenuhnya sebelum menampilkan animasi
  setTimeout(() => {
    // Pastikan modal benar-benar tertutup
    if (!modal.classList.contains('show')) {
      showPaymentSuccess(gameName, playerId, denomLabel, payment, price);
      
      // Tambahkan transaksi ke history
      addTransaction(gameKey, playerId, denomLabel, payment, price);
    } else {
      // Jika modal masih terbuka, coba lagi
      setTimeout(() => {
        showPaymentSuccess(gameName, playerId, denomLabel, payment, price);
        addTransaction(gameKey, playerId, denomLabel, payment, price);
      }, 500);
    }
  }, 300); // Tunggu 300ms setelah modal mulai menutup
});

// Login Modal
const loginModal = document.getElementById('loginModal');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const showRegister = document.getElementById('showRegister');
const loginForm = document.getElementById('loginForm');

loginBtn.addEventListener('click', function() {
  loginModal.classList.add('show');
  playSound('click');
});

registerBtn.addEventListener('click', function() {
  showNotification('Info', 'Fitur pendaftaran akan segera tersedia');
  playSound('click');
});

showRegister.addEventListener('click', function(e) {
  e.preventDefault();
  showNotification('Info', 'Fitur pendaftaran akan segera tersedia');
  playSound('click');
});

loginForm.addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  // Simulate login process
  showNotification('Berhasil!', `Selamat datang kembali, ${email}`);
  loginModal.classList.remove('show');
  playSound('success');
});

// Chat Widget
const chatToggle = document.getElementById('chatToggle');
const chatContainer = document.getElementById('chatContainer');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const chatSend = document.getElementById('chatSend');

chatToggle.addEventListener('click', function() {
  chatContainer.classList.toggle('show');
  this.classList.toggle('active');
  playSound('click');
});

// Chat Options
document.querySelectorAll('.chat-option').forEach(option => {
  option.addEventListener('click', function() {
    const message = this.getAttribute('data-message');
    addMessage(message, 'user');
    
    // Remove options after selection
    document.querySelector('.chat-options').style.display = 'none';
    
    // Show typing indicator
    showTypingIndicator();
    
    // Simulate bot response
    setTimeout(() => {
      removeTypingIndicator();
      let response = '';
      
      switch(message) {
        case 'Cara top-up':
          response = 'Untuk melakukan top-up, silakan pilih game yang diinginkan, masukkan Player ID, pilih nominal, dan metode pembayaran. Prosesnya cepat dan mudah!';
          break;
        case 'Cek status transaksi':
          response = 'Silakan masukkan nomor transaksi Anda untuk mengecek status. Atau bisa juga cek di menu Riwayat Transaksi di akun Anda.';
          break;
        case 'Promo hari ini':
          response = 'Promo hari ini: Flash Sale 50% untuk semua game! Gunakan kode promo: FLASH50. Berlaku sampai pukul 23:59 WIB.';
          break;
        case 'Hubungi CS':
          response = 'Anda akan dihubungkan dengan customer service kami dalam beberapa saat. Mohon tunggu sebentar...';
          break;
        default:
          response = 'Terima kasih atas pertanyaan Anda. Tim kami akan segera membantu Anda.';
      }
      
      addMessage(response, 'bot');
      
      // Show options again
      setTimeout(() => {
        showChatOptions();
      }, 1000);
    }, 1500);
  });
});

function addMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message', sender);
  messageDiv.textContent = message;
  chatMessages.appendChild(messageDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
  const typingDiv = document.createElement('div');
  typingDiv.classList.add('typing-indicator');
  typingDiv.innerHTML = `
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
  `;
  typingDiv.id = 'typingIndicator';
  chatMessages.appendChild(typingDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
  const typingIndicator = document.getElementById('typingIndicator');
  if (typingIndicator) {
    typingIndicator.remove();
  }
}

function showChatOptions() {
  const optionsDiv = document.createElement('div');
  optionsDiv.classList.add('chat-options');
  optionsDiv.innerHTML = `
    <div class="chat-option" data-message="Cara top-up">Cara top-up</div>
    <div class="chat-option" data-message="Cek status transaksi">Cek status transaksi</div>
    <div class="chat-option" data-message="Promo hari ini">Promo hari ini</div>
    <div class="chat-option" data-message="Hubungi CS">Hubungi CS</div>
  `;
  
  // Add event listeners to new options
  optionsDiv.querySelectorAll('.chat-option').forEach(option => {
    option.addEventListener('click', function() {
      const message = this.getAttribute('data-message');
      addMessage(message, 'user');
      optionsDiv.style.display = 'none';
      
      showTypingIndicator();
      
      setTimeout(() => {
        removeTypingIndicator();
        let response = '';
        
        switch(message) {
          case 'Cara top-up':
            response = 'Untuk melakukan top-up, silakan pilih game yang diinginkan, masukkan Player ID, pilih nominal, dan metode pembayaran. Prosesnya cepat dan mudah!';
            break;
          case 'Cek status transaksi':
            response = 'Silakan masukkan nomor transaksi Anda untuk mengecek status. Atau bisa juga cek di menu Riwayat Transaksi di akun Anda.';
            break;
          case 'Promo hari ini':
            response = 'Promo hari ini: Flash Sale 50% untuk semua game! Gunakan kode promo: FLASH50. Berlaku sampai pukul 23:59 WIB.';
            break;
          case 'Hubungi CS':
            response = 'Anda akan dihubungkan dengan customer service kami dalam beberapa saat. Mohon tunggu sebentar...';
            break;
          default:
            response = 'Terima kasih atas pesan Anda. Tim kami akan segera merespons pertanyaan Anda.';
        }
        
        addMessage(response, 'bot');
        
        setTimeout(() => {
          showChatOptions();
        }, 1000);
      }, 1500);
    });
  });
  
  chatMessages.appendChild(optionsDiv);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Send message
function sendMessage() {
  const message = chatInput.value.trim();
  if (message) {
    addMessage(message, 'user');
    chatInput.value = '';
    
    // Remove options
    const options = chatMessages.querySelector('.chat-options');
    if (options) {
      options.style.display = 'none';
    }
    
    // Show typing indicator
    showTypingIndicator();
    
    // Simulate bot response
    setTimeout(() => {
      removeTypingIndicator();
      const response = 'Terima kasih atas pesan Anda. Tim kami akan segera merespons pertanyaan Anda.';
      addMessage(response, 'bot');
      
      // Show options again
      setTimeout(() => {
        showChatOptions();
      }, 1000);
    }, 1500);
  }
}

chatSend.addEventListener('click', () => {
  sendMessage();
  playSound('click');
});

chatInput.addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    sendMessage();
  }
});

// Notification
function showNotification(title, message, type = 'success') {
  const container = document.getElementById('notificationContainer');
  
  const notificationDiv = document.createElement('div');
  notificationDiv.className = `notification-item ${type}`;
  
  const icon = type === 'success' ? 'check-circle' : 
               type === 'error' ? 'exclamation-circle' :
               type === 'warning' ? 'exclamation-triangle' : 'info-circle';
  
  notificationDiv.innerHTML = `
    <i class="fas fa-${icon} notification-icon" style="font-size: 1.5rem;"></i>
    <div style="flex: 1;">
      <div style="font-weight: 600; margin-bottom: 0.25rem;">${title}</div>
      <div style="font-size: 0.9rem; opacity: 0.9;">${message}</div>
    </div>
    <button class="notification-close" style="background: none; border: none; color: white; cursor: pointer; opacity: 0.7;">
      <i class="fas fa-times"></i>
    </button>
  `;
  
  container.appendChild(notificationDiv);
  
  // Add close functionality
  const closeBtn = notificationDiv.querySelector('.notification-close');
  closeBtn.addEventListener('click', () => {
    notificationDiv.style.animation = 'slideOut 0.5s forwards';
    setTimeout(() => notificationDiv.remove(), 500);
  });
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notificationDiv.parentNode) {
      notificationDiv.style.animation = 'slideOut 0.5s forwards';
      setTimeout(() => notificationDiv.remove(), 500);
    }
  }, 5000);
  
  playSound('notification');
}

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Scroll Progress Indicator
window.addEventListener('scroll', function() {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  const scrollPercent = (scrollTop / scrollHeight) * 100;
  
  document.querySelector('.scroll-progress-bar').style.width = scrollPercent + '%';
  
  // Show/hide back to top button
  const backToTop = document.getElementById('backToTop');
  if (scrollTop > 300) {
    backToTop.classList.add('show');
  } else {
    backToTop.classList.remove('show');
  }
});

// Back to Top Button
document.getElementById('backToTop').addEventListener('click', function() {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
  playSound('click');
});

// Sound Toggle
document.getElementById('soundToggle').addEventListener('click', function() {
  soundEnabled = !soundEnabled;
  this.classList.toggle('muted');
  
  const icon = this.querySelector('i');
  if (soundEnabled) {
    icon.classList.remove('fa-volume-mute');
    icon.classList.add('fa-volume-up');
  } else {
    icon.classList.remove('fa-volume-up');
    icon.classList.add('fa-volume-mute');
  }
});

function playSound(soundName) {
  if (soundEnabled && sounds[soundName]) {
    sounds[soundName].currentTime = 0;
    sounds[soundName].play().catch(e => console.log('Audio play failed:', e));
  }
}

// Countdown Timer
function startCountdown() {
  // Set countdown to 24 hours from now
  const countDownDate = new Date().getTime() + (24 * 60 * 60 * 1000);
  
  const timer = setInterval(function() {
    const now = new Date().getTime();
    const distance = countDownDate - now;
    
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
    document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
    document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
    
    if (distance < 0) {
      clearInterval(timer);
      document.getElementById('hours').textContent = '00';
      document.getElementById('minutes').textContent = '00';
      document.getElementById('seconds').textContent = '00';
    }
  }, 1000);
}

// Currency Converter
function updateCurrencyConverter() {
  const amount = document.getElementById('amount');
  const fromCurrency = document.getElementById('fromCurrency');
  const toCurrency = document.getElementById('toCurrency');
  const result = document.getElementById('converterResult');
  
  function convert() {
    const value = parseFloat(amount.value) || 0;
    const from = fromCurrency.value;
    const to = toCurrency.value;
    
    // Simple conversion rates (in real app, fetch from API)
    const rates = {
      'IDR': 1,
      'USD': 0.000067
    };
    
    const convertedValue = (value * rates[to]) / rates[from];
    
    if (to === 'USD') {
      result.textContent = `$${convertedValue.toFixed(2)} USD`;
    } else {
      result.textContent = `Rp ${convertedValue.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, '.')} IDR`;
    }
  }
  
  amount.addEventListener('input', convert);
  fromCurrency.addEventListener('change', convert);
  toCurrency.addEventListener('change', convert);
  
  convert();
}

// Copy Referral Code
function copyReferralCode() {
  const referralInput = document.querySelector('.referral-input');
  referralInput.select();
  referralInput.setSelectionRange(0, 99999);
  document.execCommand('copy');
  
  showNotification('Berhasil!', 'Kode referral telah disalin');
  playSound('success');
}

// FAQ Functionality
const faqItems = document.querySelectorAll('.faq-item');
faqItems.forEach(item => {
  const question = item.querySelector('.faq-question');
  question.addEventListener('click', () => {
    const isActive = item.classList.contains('active');
    
    // Close all FAQ items
    faqItems.forEach(faq => {
      faq.classList.remove('active');
    });
    
    // Open clicked item if it wasn't active
    if (!isActive) {
      item.classList.add('active');
    }
    
    playSound('click');
  });
});

// Shopping Cart System
let cart = [];
const cartToggle = document.getElementById('cartToggle');
const cartContainer = document.getElementById('cartContainer');
const cartItems = document.getElementById('cartItems');
const cartCount = document.getElementById('cartCount');
const cartTotal = document.getElementById('cartTotal');
const clearCart = document.getElementById('clearCart');
const cartCheckout = document.getElementById('cartCheckout');

// Toggle cart
cartToggle.addEventListener('click', () => {
  cartContainer.classList.toggle('show');
  playSound('click');
});

// Add to cart function
function addToCart(gameKey, denomValue, denomLabel, price) {
  const existingItem = cart.find(item => 
    item.gameKey === gameKey && item.denomValue === denomValue
  );
  
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      gameKey,
      denomValue,
      denomLabel,
      price,
      quantity: 1
    });
  }
  
  updateCart();
  showNotification('Berhasil!', 'Item ditambahkan ke keranjang');
  playSound('success');
}

// Update cart display
function updateCart() {
  if (cart.length === 0) {
    cartItems.innerHTML = '<p class="cart-empty">Keranjang kosong</p>';
    cartCount.textContent = '0';
    cartTotal.textContent = 'Rp 0';
    return;
  }
  
  cartItems.innerHTML = '';
  let total = 0;
  let itemCount = 0;
  
  cart.forEach((item, index) => {
    const itemPrice = parseInt(item.price.replace(/[^\d]/g, ''));
    const itemTotal = itemPrice * item.quantity;
    total += itemTotal;
    itemCount += item.quantity;
    
    const cartItem = document.createElement('div');
    cartItem.className = 'cart-item';
    cartItem.innerHTML = `
      <div class="cart-item-info">
        <div class="cart-item-game">${gameData[item.gameKey].name}</div>
        <div class="cart-item-details">${item.denomLabel} x${item.quantity}</div>
      </div>
      <div class="cart-item-price">Rp ${itemTotal.toLocaleString('id-ID')}</div>
      <button class="cart-item-remove" onclick="removeFromCart(${index})">
        <i class="fas fa-trash"></i>
      </button>
    `;
    cartItems.appendChild(cartItem);
  });
  
  cartCount.textContent = itemCount;
  cartTotal.textContent = `Rp ${total.toLocaleString('id-ID')}`;
}

// Remove from cart
function removeFromCart(index) {
  cart.splice(index, 1);
  updateCart();
  playSound('click');
}

// Clear cart
clearCart.addEventListener('click', () => {
  if (confirm('Hapus semua item dari keranjang?')) {
    cart = [];
    updateCart();
    playSound('click');
  }
});

// Checkout
cartCheckout.addEventListener('click', () => {
  if (cart.length === 0) {
    showNotification('Peringatan', 'Keranjang belanja kosong');
    return;
  }
  
  // Close cart
  cartContainer.classList.remove('show');
  
  // Show checkout modal
  showNotification('Info', 'Fitur checkout akan segera tersedia');
});

// Wishlist System
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

// Add wishlist button to game cards
gameCards.forEach(card => {
  const wishlistBtn = document.createElement('button');
  wishlistBtn.className = 'wishlist-btn';
  wishlistBtn.innerHTML = '<i class="far fa-heart"></i>';
  
  const gameKey = card.getAttribute('data-game');
  if (wishlist.includes(gameKey)) {
    wishlistBtn.classList.add('active');
    wishlistBtn.innerHTML = '<i class="fas fa-heart"></i>';
  }
  
  card.appendChild(wishlistBtn);
  
  wishlistBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleWishlist(gameKey, wishlistBtn);
  });
});

function toggleWishlist(gameKey, btn) {
  const index = wishlist.indexOf(gameKey);
  
  if (index > -1) {
    wishlist.splice(index, 1);
    btn.classList.remove('active');
    btn.innerHTML = '<i class="far fa-heart"></i>';
    showNotification('Dihapus', 'Game dihapus dari favorit');
  } else {
    wishlist.push(gameKey);
    btn.classList.add('active');
    btn.innerHTML = '<i class="fas fa-heart"></i>';
    showNotification('Ditambahkan', 'Game ditambahkan ke favorit');
  }
  
  localStorage.setItem('wishlist', JSON.stringify(wishlist));
  updateWishlistDisplay();
  playSound('click');
}

function updateWishlistDisplay() {
  const wishlistGrid = document.getElementById('wishlistGrid');
  
  if (wishlist.length === 0) {
    wishlistGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: rgba(255,255,255,0.5);">Belum ada game favorit</p>';
    return;
  }
  
  wishlistGrid.innerHTML = '';
  
  wishlist.forEach(gameKey => {
    const game = gameData[gameKey];
    const wishlistItem = document.createElement('div');
    wishlistItem.className = 'wishlist-item';
    wishlistItem.innerHTML = `
      <div class="game-icon" style="color: var(--neon-blue); font-size: 3rem; margin-bottom: 1rem;">
        ${getGameIcon(gameKey)}
      </div>
      <h4>${game.name}</h4>
      <p style="color: rgba(255,255,255,0.7); margin: 0.5rem 0;">${game.currency}</p>
      <button class="hero-btn hero-btn-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem; margin-top: 1rem;" 
              onclick="openGameModal('${gameKey}')">
        Top-Up Sekarang
      </button>
    `;
    wishlistGrid.appendChild(wishlistItem);
  });
}

function getGameIcon(gameKey) {
  const icons = {
    'mobile-legends': '<i class="fas fa-shield-alt"></i>',
    'pubg': '<i class="fas fa-crosshairs"></i>',
    'free-fire': '<i class="fas fa-fire"></i>',
    'codm': '<i class="fas fa-user-ninja"></i>',
    'genshin': '<i class="fas fa-wind"></i>',
    'valorant': '<i class="fas fa-eye"></i>',
    'aov': '<i class="fas fa-hat-wizard"></i>',
    'higgs': '<i class="fas fa-coins"></i>',
    'roblox': '<i class="fab fa-roblox"></i>'
  };
  return icons[gameKey] || '<i class="fas fa-gamepad"></i>';
}

function openGameModal(gameKey) {
  const card = document.querySelector(`[data-game="${gameKey}"]`);
  card.click();
}

// Multi-language Support
const translations = {
  id: {
    'hero-title': 'Top-Up Game Termurah',
    'hero-subtitle': 'Nikmati pengalaman bermain game tanpa batas dengan harga terbaik',
    'start-now': 'Mulai Sekarang',
    'loyalty-program': 'Program Loyalty',
    'customer-active': 'Customer Aktif',
    'game-available': 'Game Tersedia',
    'minute-process': 'Menit Proses',
    'rating': 'Rating (5.0)',
    'flash-sale': 'Flash Sale Berakhir Dalam',
    'hours': 'Jam',
    'minutes': 'Menit',
    'seconds': 'Detik',
    'search-placeholder': 'Cari game favoritmu...',
    'select-game': 'Pilih Game Favoritmu',
    'cart-empty': 'Keranjang kosong',
    'total': 'Total',
    'checkout': 'Checkout',
    'clear-all': 'Hapus Semua',
    'add-to-cart': 'Tambah ke Keranjang',
    'wishlist': 'Game Favorit Saya',
    'no-wishlist': 'Belum ada game favorit',
    'login': 'Masuk',
    'register': 'Daftar',
    'logout': 'Keluar',
    'profile': 'Profil Saya',
    'transaction-history': 'Riwayat Transaksi',
    'my-balance': 'Saldo Saya',
    'achievements': 'Pencapaian',
    'referral': 'Referral',
    'settings': 'Pengaturan'
  },
  en: {
    'hero-title': 'Cheapest Game Top-Up',
    'hero-subtitle': 'Enjoy unlimited gaming experience with the best prices',
    'start-now': 'Start Now',
    'loyalty-program': 'Loyalty Program',
    'customer-active': 'Active Customers',
    'game-available': 'Games Available',
    'minute-process': 'Minute Process',
    'rating': 'Rating (5.0)',
    'flash-sale': 'Flash Sale Ends In',
    'hours': 'Hours',
    'minutes': 'Minutes',
    'seconds': 'Seconds',
    'search-placeholder': 'Search your favorite game...',
    'select-game': 'Select Your Favorite Game',
    'cart-empty': 'Cart is empty',
    'total': 'Total',
    'checkout': 'Checkout',
    'clear-all': 'Clear All',
    'add-to-cart': 'Add to Cart',
    'wishlist': 'My Favorite Games',
    'no-wishlist': 'No favorite games yet',
    'login': 'Login',
    'register': 'Register',
    'logout': 'Logout',
    'profile': 'My Profile',
    'transaction-history': 'Transaction History',
    'my-balance': 'My Balance',
    'achievements': 'Achievements',
    'referral': 'Referral',
    'settings': 'Settings'
  }
};
let currentLang = localStorage.getItem('language') || 'id';

// Language switcher functionality
const languageBtn = document.getElementById('languageBtn');
const languageDropdown = document.getElementById('languageDropdown');

languageBtn.addEventListener('click', () => {
  languageDropdown.classList.toggle('show');
  playSound('click');
});

document.addEventListener('click', (e) => {
  if (!languageBtn.contains(e.target) && !languageDropdown.contains(e.target)) {
    languageDropdown.classList.remove('show');
  }
});

// Language selection
document.querySelectorAll('.language-option').forEach(option => {
  option.addEventListener('click', () => {
    const lang = option.getAttribute('data-lang');
    changeLanguage(lang);
    
    // Update active state
    document.querySelectorAll('.language-option').forEach(opt => {
      opt.classList.remove('active');
    });
    option.classList.add('active');
    
    languageDropdown.classList.remove('show');
  });
});

function changeLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('language', lang);
  
  // Update all translatable elements
  Object.keys(translations[lang]).forEach(key => {
    const elements = document.querySelectorAll(`[data-i18n="${key}"]`);
    elements.forEach(el => {
      el.textContent = translations[lang][key];
    });
  });
  
  // Update placeholders
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.placeholder = translations[lang]['search-placeholder'];
  }
  
  showNotification('Language Changed', `Language changed to ${lang === 'id' ? 'Bahasa Indonesia' : 'English'}`, 'info');
}

// Initialize language on load
document.addEventListener('DOMContentLoaded', () => {
  changeLanguage(currentLang);
  
  // Set active language option
  document.querySelector(`.language-option[data-lang="${currentLang}"]`).classList.add('active');
});

// Server Status System
const serverData = {
  'mobile-legends': {
    name: 'Mobile Legends',
    icon: '<i class="fas fa-shield-alt"></i>',
    status: 'online',
    ping: '45ms',
    players: '2.5M Online'
  },
  'pubg': {
    name: 'PUBG Mobile',
    icon: '<i class="fas fa-crosshairs"></i>',
    status: 'online',
    ping: '52ms',
    players: '1.8M Online'
  },
  'free-fire': {
    name: 'Free Fire',
    icon: '<i class="fas fa-fire"></i>',
    status: 'maintenance',
    ping: '-',
    players: 'Maintenance'
  },
  'codm': {
    name: 'COD Mobile',
    icon: '<i class="fas fa-user-ninja"></i>',
    status: 'online',
    ping: '38ms',
    players: '950K Online'
  },
  'genshin': {
    name: 'Genshin Impact',
    icon: '<i class="fas fa-wind"></i>',
    status: 'online',
    ping: '65ms',
    players: '3.2M Online'
  },
  'valorant': {
    name: 'Valorant',
    icon: '<i class="fas fa-eye"></i>',
    status: 'online',
    ping: '28ms',
    players: '1.5M Online'
  }
};

function updateServerStatus() {
  const serverGrid = document.getElementById('serverGrid');
  serverGrid.innerHTML = '';
  
  Object.entries(serverData).forEach(([key, server]) => {
    const serverItem = document.createElement('div');
    serverItem.className = 'server-item';
    
    const statusClass = `status-${server.status}`;
    const statusText = server.status === 'online' ? 'Online' :
                       server.status === 'maintenance' ? 'Maintenance' : 'Offline';
    
    serverItem.innerHTML = `
      <div class="server-icon" style="background: linear-gradient(45deg, var(--neon), var(--neon-blue));">
        ${server.icon}
      </div>
      <div class="server-info">
        <div class="server-name">${server.name}</div>
        <div class="server-status-text">
          <span class="status-indicator ${statusClass}"></span>
          <span>${statusText}</span>
        </div>
        <div class="server-ping">Ping: ${server.ping}</div>
        <div class="server-players">${server.players}</div>
      </div>
    `;
    
    serverGrid.appendChild(serverItem);
  });
}

// Simulate server status changes
function simulateServerStatusChanges() {
  setInterval(() => {
    // Randomly change Free Fire status
    const freeFire = serverData['free-fire'];
    if (Math.random() > 0.7) {
      freeFire.status = freeFire.status === 'maintenance' ? 'online' : 'maintenance';
      freeFire.ping = freeFire.status === 'maintenance' ? '-' : '48ms';
      freeFire.players = freeFire.status === 'maintenance' ? 'Maintenance' : '1.2M Online';
      updateServerStatus();
      
      if (freeFire.status === 'maintenance') {
        showNotification('Server Maintenance', 'Free Fire server sedang maintenance', 'warning');
      } else {
        showNotification('Server Online', 'Free Fire server kembali online', 'success');
      }
    }
  }, 30000);
}

// Quick Top-up System
let savedAccounts = JSON.parse(localStorage.getItem('savedAccounts')) || [];
let selectedAccount = null;

// Show quick top-up for logged-in users (simulation)
function showQuickTopup() {
  const quickTopup = document.getElementById('quickTopup');
  if (savedAccounts.length > 0) {
    quickTopup.classList.add('show');
    updateSavedAccounts();
  }
}

// Update saved accounts display
function updateSavedAccounts() {
  const container = document.getElementById('savedAccounts');
  container.innerHTML = '';
  
  savedAccounts.forEach((account, index) => {
    const accountDiv = document.createElement('div');
    accountDiv.className = 'saved-account';
    if (selectedAccount === index) {
      accountDiv.classList.add('selected');
    }
    
    accountDiv.innerHTML = `
      <div class="account-game">${gameData[account.gameKey].name}</div>
      <div class="account-id">ID: ${account.playerId}</div>
    `;
    
    accountDiv.addEventListener('click', () => selectAccount(index));
    container.appendChild(accountDiv);
  });
}

// Select account
function selectAccount(index) {
  selectedAccount = index;
  const account = savedAccounts[index];
  
  // Update game selection
  const quickGame = document.getElementById('quickGame');
  quickGame.innerHTML = '<option value="">Pilih Game</option>';
  
  Object.entries(gameData).forEach(([key, game]) => {
    const option = document.createElement('option');
    option.value = key;
    option.textContent = game.name;
    if (key === account.gameKey) {
      option.selected = true;
    }
    quickGame.appendChild(option);
  });
  
  // Update denominations
  updateQuickDenominations(account.gameKey);
  
  updateSavedAccounts();
}

// Update quick denominations
function updateQuickDenominations(gameKey) {
  const quickDenom = document.getElementById('quickDenom');
  quickDenom.innerHTML = '<option value="">Pilih Nominal</option>';
  
  if (gameData[gameKey] && gameData[gameKey].denominations) {
    gameData[gameKey].denominations.forEach(denom => {
      const option = document.createElement('option');
      option.value = denom.value;
      option.textContent = denom.label;
      quickDenom.appendChild(option);
    });
  }
}

// Game selection change
document.getElementById('quickGame')?.addEventListener('change', function() {
  updateQuickDenominations(this.value);
});

// Quick top-up function
function quickTopUp() {
  if (selectedAccount === null) {
    showNotification('Peringatan', 'Pilih akun terlebih dahulu', 'warning');
    return;
  }
  
  const gameKey = document.getElementById('quickGame').value;
  const denomValue = document.getElementById('quickDenom').value;
  
  if (!gameKey || !denomValue) {
    showNotification('Peringatan', 'Pilih game dan nominal', 'warning');
    return;
  }
  
  const account = savedAccounts[selectedAccount];
  const denom = gameData[gameKey].denominations.find(d => d.value === denomValue);
  
  // Process top-up
  showPaymentSuccess(
    gameData[gameKey].name,
    account.playerId,
    denom.label,
    'QRIS',
    denom.label.match(/Rp ([\d.]+)/)[0]
  );
  
  showNotification('Berhasil!', 'Top-up sedang diproses', 'success');
}

// Add save account option to top-up modal
// Handle save account
document.getElementById('topUpForm')?.addEventListener('submit', function(e) {
  const saveAccount = document.getElementById('saveAccount')?.checked;
  if (saveAccount) {
    const gameKey = modal.getAttribute('data-game-key');
    const playerId = document.getElementById('playerId').value;
    
    // Check if account already saved
    const exists = savedAccounts.some(acc => 
      acc.gameKey === gameKey && acc.playerId === playerId
    );
    
    if (!exists) {
      savedAccounts.push({ gameKey, playerId });
      localStorage.setItem('savedAccounts', JSON.stringify(savedAccounts));
      showNotification('Akun Disimpan', 'Akun telah disimpan untuk top-up cepat', 'success');
      showQuickTopup();
    }
  }
});

// Payment History System
let transactions = JSON.parse(localStorage.getItem('transactions')) || generateSampleTransactions();
let currentFilter = 'all';
let currentPage = 1;
const itemsPerPage = 10;

// Generate sample transactions
function generateSampleTransactions() {
  const sampleData = [];
  const games = Object.keys(gameData);
  const statuses = ['success', 'pending', 'failed'];
  
  for (let i = 0; i < 25; i++) {
    const gameKey = games[Math.floor(Math.random() * games.length)];
    const game = gameData[gameKey];
    const denom = game.denominations[Math.floor(Math.random() * game.denominations.length)];
    
    sampleData.push({
      id: `TRX${Date.now() + i}`,
      game: game.name,
      gameKey: gameKey,
      playerId: `12345678${Math.floor(Math.random() * 100)}`,
      nominal: denom.label,
      total: denom.label.match(/Rp ([\d.]+)/)[0],
      status: statuses[Math.floor(Math.random() * statuses.length)],
      date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString()
    });
  }
  
  return sampleData;
}

// Update transaction history display
function updateTransactionHistory() {
  const tbody = document.getElementById('historyTableBody');
  const searchTerm = document.getElementById('historySearch').value.toLowerCase();
  
  // Filter transactions
  let filtered = transactions.filter(trx => {
    const matchesFilter = currentFilter === 'all' || trx.status === currentFilter;
    const matchesSearch = searchTerm === '' || 
                         trx.id.toLowerCase().includes(searchTerm) ||
                         trx.game.toLowerCase().includes(searchTerm) ||
                         trx.playerId.toLowerCase().includes(searchTerm);
    return matchesFilter && matchesSearch;
  });
  
  // Pagination
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginated = filtered.slice(startIndex, endIndex);
  
  // Clear table
  tbody.innerHTML = '';
  
  // Add rows
  paginated.forEach(trx => {
    const row = document.createElement('tr');
    const statusClass = `status-${trx.status}`;
    const statusText = trx.status === 'success' ? 'Berhasil' :
                      trx.status === 'pending' ? 'Pending' : 'Gagal';
    
    row.innerHTML = `
      <td>${trx.id}</td>
      <td>${trx.game}</td>
      <td>${trx.playerId}</td>
      <td>${trx.nominal}</td>
      <td>Rp ${parseInt(trx.total).toLocaleString('id-ID')}</td>
      <td><span class="status-badge ${statusClass}">${statusText}</span></td>
      <td>${new Date(trx.date).toLocaleDateString('id-ID')}</td>
      <td class="history-actions">
        <button class="action-btn" onclick="viewTransaction('${trx.id}')">Detail</button>
        ${trx.status === 'pending' ? `<button class="action-btn" onclick="checkStatus('${trx.id}')">Cek Status</button>` : ''}
      </td>
    `;
    tbody.appendChild(row);
  });
  
  // Update pagination
  updatePagination(filtered.length);
}

// Update pagination
function updatePagination(totalItems) {
  const pagination = document.getElementById('pagination');
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  pagination.innerHTML = '';
  
  // Previous button
  const prevBtn = document.createElement('button');
  prevBtn.className = 'page-btn';
  prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
  prevBtn.disabled = currentPage === 1;
  prevBtn.onclick = () => {
    if (currentPage > 1) {
      currentPage--;
      updateTransactionHistory();
    }
  };
  pagination.appendChild(prevBtn);
  
  // Page numbers
  for (let i = 1; i <= totalPages; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
    pageBtn.textContent = i;
    pageBtn.onclick = () => {
      currentPage = i;
      updateTransactionHistory();
    };
    pagination.appendChild(pageBtn);
  }
  
  // Next button
  const nextBtn = document.createElement('button');
  nextBtn.className = 'page-btn';
  nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
  nextBtn.disabled = currentPage === totalPages;
  nextBtn.onclick = () => {
    if (currentPage < totalPages) {
      currentPage++;
      updateTransactionHistory();
    }
  };
  pagination.appendChild(nextBtn);
}

// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    currentFilter = this.getAttribute('data-filter');
    currentPage = 1;
    updateTransactionHistory();
  });
});

// Search functionality
document.getElementById('historySearch')?.addEventListener('input', function() {
  currentPage = 1;
  updateTransactionHistory();
});

// View transaction detail
function viewTransaction(trxId) {
  const trx = transactions.find(t => t.id === trxId);
  if (trx) {
    showNotification('Detail Transaksi', `ID: ${trx.id}\nGame: ${trx.game}\nStatus: ${trx.status}`, 'info');
  }
}

// Check transaction status
function checkStatus(trxId) {
  const trx = transactions.find(t => t.id === trxId);
  if (trx) {
    // Simulate status check
    const newStatus = Math.random() > 0.5 ? 'success' : 'failed';
    trx.status = newStatus;
    localStorage.setItem('transactions', JSON.stringify(transactions));
    updateTransactionHistory();
    
    showNotification(
      'Status Diperbarui', 
      `Transaksi ${trx.id} status: ${newStatus === 'success' ? 'Berhasil' : 'Gagal'}`,
      newStatus === 'success' ? 'success' : 'error'
    );
  }
}

// Add new transaction
function addTransaction(gameKey, playerId, denom, payment, total) {
  const newTrx = {
    id: `TRX${Date.now()}`,
    game: gameData[gameKey].name,
    gameKey: gameKey,
    playerId: playerId,
    nominal: denom,
    total: total.replace(/[^\d]/g, ''),
    status: 'pending',
    date: new Date().toISOString()
  };
  
  transactions.unshift(newTrx);
  localStorage.setItem('transactions', JSON.stringify(transactions));
  updateTransactionHistory();
}

// Simulate real-time notifications
function simulateRealtimeNotifications() {
  const notifications = [
    { title: 'Promo Spesial!', message: 'Flash Sale 50% untuk semua game berakhir dalam 2 jam!', type: 'warning' },
    { title: 'Transaksi Berhasil', message: 'Top-up Mobile Legends 514 Diamond berhasil diproses', type: 'success' },
    { title: 'Maintenance', message: 'Server PUBG Mobile akan maintenance pukul 02:00 - 05:00 WIB', type: 'info' },
    { title: 'Bonus Loyalty', message: 'Selamat! Anda mendapatkan bonus 100 poin loyalty', type: 'success' }
  ];
  
  let index = 0;
  setInterval(() => {
    if (index < notifications.length) {
      const notif = notifications[index];
      showNotification(notif.title, notif.message, notif.type);
      index++;
    }
  }, 15000);
}

// Add transaction when payment is successful
// Event listener for success button
document.addEventListener('DOMContentLoaded', function() {
  // Event listener khusus untuk tombol success
  const successBtn = document.getElementById('successBtn');
  if (successBtn) {
    // Hapus event listener yang mungkin sudah ada
    successBtn.replaceWith(successBtn.cloneNode(true));
    
    // Tambahkan event listener baru
    const newSuccessBtn = document.getElementById('successBtn');
    newSuccessBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      console.log('Tombol Selesai diklik');
      
      // Sembunyikan animasi pembayaran sukses
      const successElement = document.getElementById('paymentSuccess');
      if (successElement) {
        successElement.classList.remove('show');
        
        // Tampilkan notifikasi
        showNotification('Transaksi Selesai', 'Terima kasih telah bertransaksi di SanzzShop!', 'success');
        playSound('click');
        
        // Reset form jika perlu
        const topUpForm = document.getElementById('topUpForm');
        if (topUpForm) {
          topUpForm.reset();
        }
      }
    });
    
    // Debug: Pastikan tombol bisa diklik
    console.log('Tombol Selesai ditemukan dan event listener ditambahkan');
  }
  
  // Event delegation sebagai backup
  document.body.addEventListener('click', function(e) {
    if (e.target.closest('#successBtn')) {
      e.preventDefault();
      e.stopPropagation();
      
      console.log('Tombol Selesai diklik via event delegation');
      
      const successElement = document.getElementById('paymentSuccess');
      if (successElement) {
        successElement.classList.remove('show');
        showNotification('Transaksi Selesai', 'Terima kasih telah bertransaksi di SanzzShop!', 'success');
        playSound('click');
        
        const topUpForm = document.getElementById('topUpForm');
        if (topUpForm) {
          topUpForm.reset();
        }
      }
    }
  });
  
  // Event untuk menutup payment success dengan klik di luar
  document.addEventListener('click', function(e) {
    const successElement = document.getElementById('paymentSuccess');
    if (successElement && successElement.classList.contains('show') && 
        e.target === successElement) {
      successElement.classList.remove('show');
      showNotification('Transaksi Dibatalkan', 'Anda menutup halaman pembayaran', 'info');
    }
  });
});

// Add some interactive effects
document.addEventListener('mousemove', function(e) {
  const cards = document.querySelectorAll('.game-card');
  const x = e.clientX / window.innerWidth;
  const y = e.clientY / window.innerHeight;
  
  cards.forEach(card => {
    const rect = card.getBoundingClientRect();
    const cardX = rect.left + rect.width / 2;
    const cardY = rect.top + rect.height / 2;
    const angleX = (e.clientY - cardY) * 0.01;
    const angleY = (e.clientX - cardX) * -0.01;
    
    if (e.clientX >= rect.left && e.clientX <= rect.right && 
        e.clientY >= rect.top && e.clientY <= rect.bottom) {
      card.style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg) translateZ(10px)`;
    }
  });
});

// Reset card transforms when mouse leaves
document.querySelectorAll('.game-card').forEach(card => {
  card.addEventListener('mouseleave', function() {
    this.style.transform = '';
  });
});

// Add parallax effect to hero section
window.addEventListener('scroll', function() {
  const scrolled = window.pageYOffset;
  const hero = document.querySelector('.hero');
  hero.style.transform = `translateY(${scrolled * 0.5}px)`;
});

// Add glow effect on scroll
window.addEventListener('scroll', function() {
  const scrolled = window.pageYOffset;
  const maxScroll = 300;
  const opacity = Math.min(scrolled / maxScroll, 1);
  
  document.body.style.boxShadow = `inset 0 0 ${100 * opacity}px rgba(167, 139, 250, ${0.3 * opacity})`;
});

// Typewriter effect for hero title
function typeWriter() {
  const title = document.querySelector('.hero-title');
  const text = title.textContent;
  title.textContent = '';
  let i = 0;
  
  function type() {
    if (i < text.length) {
      title.textContent += text.charAt(i);
      i++;
      setTimeout(type, 100);
    }
  }
  
  type();
}

// Initialize typewriter effect after loading
setTimeout(typeWriter, 2500);